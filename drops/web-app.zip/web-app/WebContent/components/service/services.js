'use strict';
angular.module('salesApp.services', [
  'salesApp.services.customers',
  'salesApp.services.products',
  'salesApp.services.tax',
  'salesApp.services.validation',
  'salesApp.services.repairService'
])
