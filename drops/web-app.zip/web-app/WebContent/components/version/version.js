'use strict';
angular.module('salesApp.version', [
  'salesApp.version.version-directive'
])
