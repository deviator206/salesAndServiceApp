package test;

public class MyTestableClass {

	public int multiply(int i, int j) {
		return i*j;
	}

}
