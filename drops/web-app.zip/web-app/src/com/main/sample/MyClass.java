package com.main.sample;

public class MyClass {

	private int a;
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	public int getB() {
		return b;
	}
	public void setB(int b) {
		this.b = b;
	}
	private int b;
	
	
	public int add(int p, int q){
		return p+q;
	}
	public int subtract(int p, int q){
		return p-q;
	}
}
