// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CommentsInfoModel.java

package com.main.models;


public class CommentsInfoModel
{

    public CommentsInfoModel()
    {
    }

    public String getTech()
    {
        return tech;
    }

    public void setTech(String tech)
    {
        this.tech = tech;
    }

    public String getShopkeeper()
    {
        return shopkeeper;
    }

    public void setShopkeeper(String shopkeeper)
    {
        this.shopkeeper = shopkeeper;
    }

    public String getCustomer()
    {
        return customer;
    }

    public void setCustomer(String customer)
    {
        this.customer = customer;
    }

    public String getC_comment()
    {
        return c_comment;
    }

    public void setC_comment(String c_comment)
    {
        this.c_comment = c_comment;
    }

    public String getCa_comment()
    {
        return ca_comment;
    }

    public void setCa_comment(String ca_comment)
    {
        this.ca_comment = ca_comment;
    }

    public String getPp_comment()
    {
        return pp_comment;
    }

    public void setPp_comment(String pp_comment)
    {
        this.pp_comment = pp_comment;
    }

    public String getTh_comment()
    {
        return th_comment;
    }

    public void setTh_comment(String th_comment)
    {
        this.th_comment = th_comment;
    }

    private String tech;
    private String shopkeeper;
    private String customer;
    private String c_comment;
    private String ca_comment;
    private String pp_comment;
    private String th_comment;
}
