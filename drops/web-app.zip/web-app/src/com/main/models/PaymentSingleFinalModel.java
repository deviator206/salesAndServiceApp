// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PaymentSingleFinalModel.java

package com.main.models;


public class PaymentSingleFinalModel
{

    public PaymentSingleFinalModel()
    {
    }

    public String getPaymentType()
    {
        return paymentType;
    }

    public void setPaymentType(String paymentType)
    {
        this.paymentType = paymentType;
    }

    public String getFinal_cash()
    {
        return final_cash;
    }

    public void setFinal_cash(String final_cash)
    {
        this.final_cash = final_cash;
    }

    public String getFinal_cheqNo()
    {
        return final_cheqNo;
    }

    public void setFinal_cheqNo(String final_cheqNo)
    {
        this.final_cheqNo = final_cheqNo;
    }

    public String getFinal_bankName()
    {
        return final_bankName;
    }

    public void setFinal_bankName(String final_bankName)
    {
        this.final_bankName = final_bankName;
    }

    public String getFinal_cheqDate()
    {
        return final_cheqDate;
    }

    public void setFinal_cheqDate(String final_cheqDate)
    {
        this.final_cheqDate = final_cheqDate;
    }

    public String getFinal_cardNo()
    {
        return final_cardNo;
    }

    public void setFinal_cardNo(String final_cardNo)
    {
        this.final_cardNo = final_cardNo;
    }

    public String getFinal_amount()
    {
        return final_amount;
    }

    public void setFinal_amount(String final_amount)
    {
        this.final_amount = final_amount;
    }

    public String getFinal_onlinePaymentMode()
    {
        return final_onlinePaymentMode;
    }

    public void setFinal_onlinePaymentMode(String final_onlinePaymentMode)
    {
        this.final_onlinePaymentMode = final_onlinePaymentMode;
    }

    public String getFinal_onlineTransactionId()
    {
        return final_onlineTransactionId;
    }

    public void setFinal_onlineTransactionId(String final_onlineTransactionId)
    {
        this.final_onlineTransactionId = final_onlineTransactionId;
    }

    public String getFinal_onlineRemark()
    {
        return final_onlineRemark;
    }

    public void setFinal_onlineRemark(String final_onlineRemark)
    {
        this.final_onlineRemark = final_onlineRemark;
    }

    public String getFinal_cardNetwork()
    {
        return final_cardNetwork;
    }

    public void setFinal_cardNetwork(String final_cardNetwork)
    {
        this.final_cardNetwork = final_cardNetwork;
    }

    private String paymentType;
    private String final_cash;
    private String final_cheqNo;
    private String final_bankName;
    private String final_cheqDate;
    private String final_cardNo;
    private String final_amount;
    private String final_onlinePaymentMode;
    private String final_onlineTransactionId;
    private String final_onlineRemark;
    private String final_cardNetwork;
}
