// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   UpdateRepairServiceResponse.java

package com.main.models;


// Referenced classes of package com.main.models:
//            MainResponse

public class UpdateRepairServiceResponse extends MainResponse
{

    public UpdateRepairServiceResponse()
    {
    }
}
