# WARNING: Cannot generate character set or collation names without the --server option.
# CAUTION: The diagnostic mode is a best-effort parse of the .frm file. As such, it may not identify all of the components of the table correctly. This is especially true for damaged files. It will also not read the default values for the columns and the resulting statement may not be syntactically correct.
# Reading .frm file for E:\Sandeep-camERP\23rd_Dec_2020\dump_from_program_data\nce_db\emp_customer_table.frm:
# The .frm file is a TABLE.
# CREATE TABLE Statement:

CREATE TABLE `nce_db`.`emp_customer_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT, 
  `name` varchar(765) DEFAULT NULL, 
  `address` varchar(765) DEFAULT NULL, 
  `phone` varchar(45) DEFAULT NULL, 
  `alternate_number` varchar(270) DEFAULT NULL, 
  `email_id` varchar(270) DEFAULT NULL, 
PRIMARY KEY `PRIMARY` (`id`)
) ENGINE=InnoDB;

# Reading .frm file for E:\Sandeep-camERP\23rd_Dec_2020\dump_from_program_data\nce_db\emp_product_table.frm:
# The .frm file is a TABLE.
# CREATE TABLE Statement:

CREATE TABLE `nce_db`.`emp_product_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT, 
  `brandName` varchar(300) DEFAULT NULL, 
  `brandModel` varchar(300) DEFAULT NULL, 
  `serialNumber` varchar(300) DEFAULT NULL, 
  `price` int(30) DEFAULT NULL, 
  `tax_type` varchar(90) DEFAULT NULL, 
  `stockQuantity` int(30) DEFAULT NULL, 
  `isService` tinyint(1) DEFAULT NULL, 
PRIMARY KEY `PRIMARY` (`id`)
) ENGINE=InnoDB;

# Reading .frm file for E:\Sandeep-camERP\23rd_Dec_2020\dump_from_program_data\nce_db\payment_details_table.frm:
# The .frm file is a TABLE.
# CREATE TABLE Statement:

CREATE TABLE `nce_db`.`payment_details_table` (
  `id` int(40) NOT NULL AUTO_INCREMENT, 
  `cash` varchar(180) DEFAULT NULL, 
  `cheqNo` varchar(180) DEFAULT NULL, 
  `bankName` varchar(180) DEFAULT NULL, 
  `ifscCode` varchar(180) DEFAULT NULL, 
  `cheqDate` varchar(180) DEFAULT NULL, 
  `accountNo` varchar(180) DEFAULT NULL, 
  `cardNo` varchar(180) DEFAULT NULL, 
  `invoice_id` varchar(180) DEFAULT NULL, 
  `invoice_tin` varchar(180) DEFAULT NULL, 
  `amount` float(40,2) DEFAULT NULL, 
  `onlinePaymentMode` varchar(165) DEFAULT NULL, 
  `onlineTransactionId` varchar(165) DEFAULT NULL, 
  `onlineRemark` varchar(165) DEFAULT NULL, 
  `cardExpiryDate` varchar(165) DEFAULT NULL, 
  `cardNetwork` varchar(165) DEFAULT NULL, 
  `cardBank` varchar(165) DEFAULT NULL, 
  `final_cash` varchar(180) DEFAULT NULL, 
  `final_cheqNo` varchar(180) DEFAULT NULL, 
  `final_cheqDate` varchar(180) DEFAULT NULL, 
  `final_bankName` varchar(180) DEFAULT NULL, 
  `final_cardNo` varchar(180) DEFAULT NULL, 
  `final_cardNetwork` varchar(180) DEFAULT NULL, 
  `final_onlinePaymentMode` varchar(180) DEFAULT NULL, 
  `final_onlineTransactionId` varchar(180) DEFAULT NULL, 
  `final_onlineRemark` varchar(180) DEFAULT NULL, 
  `final_amount` varchar(180) DEFAULT NULL, 
PRIMARY KEY `PRIMARY` (`id`)
) ENGINE=InnoDB;

# Reading .frm file for E:\Sandeep-camERP\23rd_Dec_2020\dump_from_program_data\nce_db\repair_invoice_table.frm:
# The .frm file is a TABLE.
# CREATE TABLE Statement:

CREATE TABLE `nce_db`.`repair_invoice_table` (
  `id` int(30) NOT NULL AUTO_INCREMENT, 
  `actualInvoiceId` varchar(180) DEFAULT NULL, 
  `defaultValue` varchar(180) NOT NULL, 
  `vat_tin_number` varchar(180) DEFAULT NULL, 
PRIMARY KEY `PRIMARY` (`id`),
UNIQUE KEY `actualInvoiceId` (`actualInvoiceId`)
) ENGINE=InnoDB;

# Reading .frm file for E:\Sandeep-camERP\23rd_Dec_2020\dump_from_program_data\nce_db\sales_invoice_table.frm:
# The .frm file is a TABLE.
# CREATE TABLE Statement:

CREATE TABLE `nce_db`.`sales_invoice_table` (
  `id` int(30) NOT NULL AUTO_INCREMENT, 
  `actualInvoiceId` varchar(180) DEFAULT NULL, 
  `defaultValue` varchar(180) DEFAULT NULL, 
  `vat_tin_number` varchar(180) DEFAULT NULL, 
PRIMARY KEY `PRIMARY` (`id`),
UNIQUE KEY `actualInvoiceId` (`actualInvoiceId`)
) ENGINE=InnoDB;

# Reading .frm file for E:\Sandeep-camERP\23rd_Dec_2020\dump_from_program_data\nce_db\sales_order_table.frm:
# The .frm file is a TABLE.
# CREATE TABLE Statement:

CREATE TABLE `nce_db`.`sales_order_table` (
  `sale_id` int(30) NOT NULL AUTO_INCREMENT, 
  `invoice_id` varchar(180) NOT NULL, 
  `customer_id` varchar(180) NOT NULL, 
  `product_id` varchar(180) NOT NULL, 
  `product_unit_price` float(10,2) NOT NULL, 
  `product_qty` float(10,2) NOT NULL, 
  `product_price_with_qty` float(10,2) NOT NULL, 
  `tax_type` varchar(180) DEFAULT NULL, 
  `tax_rate` varchar(180) DEFAULT NULL, 
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
  `tax_amount` float(10,2) DEFAULT NULL, 
  `total_amount` float(10,2) NOT NULL, 
  `tax_value` float(10,2) DEFAULT NULL, 
PRIMARY KEY `PRIMARY` (`sale_id`)
) ENGINE=InnoDB;

# Reading .frm file for E:\Sandeep-camERP\23rd_Dec_2020\dump_from_program_data\nce_db\service_customer_table.frm:
# The .frm file is a TABLE.
# CREATE TABLE Statement:

CREATE TABLE `nce_db`.`service_customer_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT, 
  `name` varchar(60) DEFAULT NULL, 
  `address` varchar(150) DEFAULT NULL, 
  `phone` varchar(60) DEFAULT NULL, 
PRIMARY KEY `PRIMARY` (`id`)
) ENGINE=InnoDB;

# Reading .frm file for E:\Sandeep-camERP\23rd_Dec_2020\dump_from_program_data\nce_db\service_info_table.frm:
# The .frm file is a TABLE.
# CREATE TABLE Statement:

CREATE TABLE `nce_db`.`service_info_table` (
  `id` int(30) NOT NULL AUTO_INCREMENT, 
  `customerId` int(11) NOT NULL, 
  `productName` varchar(3600) DEFAULT NULL, 
  `productModel` varchar(1800) DEFAULT NULL, 
  `productSN` varchar(180) DEFAULT NULL, 
  `userId` int(11) NOT NULL, 
  `accessoryList` varchar(3600) DEFAULT NULL, 
  `problemList` varchar(3600) DEFAULT NULL, 
  `isCourier` tinyint(1) DEFAULT NULL, 
  `courierName` varchar(3600) DEFAULT NULL, 
  `courierPhone` varchar(750) DEFAULT NULL, 
  `techComment` varchar(3600) DEFAULT NULL, 
  `shopUserComment` varchar(3600) DEFAULT NULL, 
  `customerComment` varchar(3600) DEFAULT NULL, 
  `serviceStatus` varchar(600) DEFAULT NULL, 
  `courierDocumentNo` varchar(900) DEFAULT NULL, 
  `service_order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
  `service_completion_date` timestamp DEFAULT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
  `tentative_service_completion_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
  `tentative_quoted_cost` varchar(120) DEFAULT NULL, 
  `actual_service_cost` varchar(120) DEFAULT NULL, 
  `service_order_number` varchar(150) NOT NULL, 
  `taxName` varchar(120) DEFAULT NULL, 
  `taxRate` varchar(120) DEFAULT NULL, 
  `taxValue` varchar(120) DEFAULT NULL, 
  `vatTinNumber` varchar(180) DEFAULT NULL, 
  `advancedPayment` varchar(120) DEFAULT NULL, 
  `finalPayment` varchar(120) DEFAULT NULL, 
  `finalDeleted` varchar(765) DEFAULT NULL, 
  `technician_handle_status` varchar(240) DEFAULT NULL, 
  `technician_handle_comment` varchar(3600) DEFAULT NULL, 
  `customer_approval_status` varchar(240) DEFAULT NULL, 
  `customer_approval_comment` varchar(3600) DEFAULT NULL, 
  `part_pending_status` varchar(240) DEFAULT NULL, 
  `part_pending_comment` varchar(3600) DEFAULT NULL, 
  `technician_handle_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
  `customer_approval_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
  `part_pending_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
  `completed_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
  `tech_completed_comment` varchar(3600) DEFAULT NULL, 
  `isOutwardCourier` tinyint(1) DEFAULT NULL, 
  `outwardCourierName` varchar(1650) DEFAULT NULL, 
  `outwardCourierPhone` varchar(90) DEFAULT NULL, 
  `outwardCourierDocumentNo` varchar(165) DEFAULT NULL, 
  `estimated_delivery_cost` varchar(300) DEFAULT NULL, 
  `estimated_delivery_date` varchar(300) DEFAULT NULL, 
PRIMARY KEY `PRIMARY` (`id`),
KEY `customerId` (`customerId`),
KEY `userId` (`userId`)
) ENGINE=InnoDB;

# Reading .frm file for E:\Sandeep-camERP\23rd_Dec_2020\dump_from_program_data\nce_db\service_info_table1.frm:
# The .frm file is a TABLE.
# CREATE TABLE Statement:

CREATE TABLE `nce_db`.`service_info_table1` (
  `id` int(30) NOT NULL AUTO_INCREMENT, 
  `customerId` int(11) NOT NULL, 
  `productName` varchar(180) DEFAULT NULL, 
  `productModel` varchar(180) DEFAULT NULL, 
  `productSN` varchar(180) DEFAULT NULL, 
  `userId` int(11) NOT NULL, 
  `accessoryList` varchar(180) DEFAULT NULL, 
  `problemList` varchar(180) DEFAULT NULL, 
  `isCourier` tinyint(1) DEFAULT NULL, 
  `courierName` varchar(90) DEFAULT NULL, 
  `courierPhone` varchar(90) DEFAULT NULL, 
  `techComment` varchar(360) DEFAULT NULL, 
  `shopUserComment` varchar(360) DEFAULT NULL, 
  `customerComment` varchar(360) DEFAULT NULL, 
  `serviceStatus` varchar(60) DEFAULT NULL, 
  `courierDocumentNo` varchar(90) DEFAULT NULL, 
  `service_order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
  `service_completion_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
  `tentative_service_completion_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
  `tentative_quoted_cost` varchar(120) DEFAULT NULL, 
  `actual_service_cost` varchar(120) DEFAULT NULL, 
  `service_order_number` varchar(150) NOT NULL, 
  `taxName` varchar(120) DEFAULT NULL, 
  `taxRate` varchar(120) DEFAULT NULL, 
  `taxValue` varchar(120) DEFAULT NULL, 
  `vatTinNumber` varchar(180) DEFAULT NULL, 
  `advancedPayment` varchar(120) DEFAULT NULL, 
  `finalPayment` varchar(120) DEFAULT NULL, 
PRIMARY KEY `PRIMARY` (`id`),
KEY `customerId` (`customerId`),
KEY `userId` (`userId`)
) ENGINE=InnoDB;

# Reading .frm file for E:\Sandeep-camERP\23rd_Dec_2020\dump_from_program_data\nce_db\validemporiumuser.frm:
# The .frm file is a TABLE.
# CREATE TABLE Statement:

CREATE TABLE `nce_db`.`validemporiumuser` (
  `empId` int(11) NOT NULL AUTO_INCREMENT, 
  `empName` varchar(60) DEFAULT NULL, 
  `empPassword` varchar(60) DEFAULT NULL, 
  `empRole` varchar(30) DEFAULT NULL, 
PRIMARY KEY `PRIMARY` (`empId`)
) ENGINE=InnoDB;

#...done.
