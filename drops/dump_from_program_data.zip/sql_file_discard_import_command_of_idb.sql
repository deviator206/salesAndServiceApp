select count(*) from repair_invoice_table

ALTER TABLE repair_invoice_table DISCARD TABLESPACE;

ALTER TABLE repair_invoice_table IMPORT TABLESPACE;

select  * from repair_invoice_table where actualInvoiceId='CE/2019-20/324'



ALTER TABLE emp_customer_table DISCARD TABLESPACE;
ALTER TABLE emp_product_table DISCARD TABLESPACE;
ALTER TABLE payment_details_table DISCARD TABLESPACE;
ALTER TABLE sales_invoice_table DISCARD TABLESPACE;
ALTER TABLE sales_order_table DISCARD TABLESPACE;
ALTER TABLE service_customer_table DISCARD TABLESPACE;
ALTER TABLE service_info_table DISCARD TABLESPACE;
ALTER TABLE service_info_table1 DISCARD TABLESPACE;
ALTER TABLE validemporiumuser DISCARD TABLESPACE;



ALTER TABLE emp_customer_table IMPORT TABLESPACE;
ALTER TABLE emp_product_table IMPORT TABLESPACE;
ALTER TABLE payment_details_table IMPORT TABLESPACE;
ALTER TABLE sales_invoice_table IMPORT TABLESPACE;
ALTER TABLE sales_order_table IMPORT TABLESPACE;
ALTER TABLE service_customer_table IMPORT TABLESPACE;
ALTER TABLE service_info_table IMPORT TABLESPACE;
ALTER TABLE service_info_table1 IMPORT TABLESPACE;
ALTER TABLE validemporiumuser IMPORT TABLESPACE;